﻿namespace StringFormatting
{
    public interface IStringFormatter
    {
        string Format(string formatString, object parameter);
    }
}
